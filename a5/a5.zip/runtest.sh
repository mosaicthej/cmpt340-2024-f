swipl a5.prolog p3-queries.prolog < 5-3.txt > testout.txt
